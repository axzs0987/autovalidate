﻿using ExcelReader;
using System;
using System.IO;
using System.IO.Compression;

namespace Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            var entry = "000/02e165d0811294ede088ac084aa23a95_c2Vla2luZ2FscGhhLmNvbQkxNTEuMTAxLjY2LjI=.xls.xlsx";
            var zipfile = @"\\msrasa\TableLint\Datasets\ToYeye\WithValidations\\000.zip";
            using (var fs = File.Open(zipfile, FileMode.Open, FileAccess.Read))
            {
                var archive = new ZipArchive(fs, ZipArchiveMode.Read);
                using (var zs = archive.GetEntry(entry).Open())
                {
                    var workbook = Worker.ExtractWorkbook(zs, entry);
                    File.WriteAllText(@"workbook.json", Worker.Jsonify(workbook));
                }
            }
            Console.WriteLine("Hello World!");
        }
    }
}